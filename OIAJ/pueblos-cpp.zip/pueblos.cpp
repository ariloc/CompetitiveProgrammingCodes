#include <string>

using namespace std;

void inicializar(int Q,int M)
{
    // AQUI SE DEBE PROGRAMAR LA SOLUCION
}

long long pueblo(string A, long long PA)
{
    // AQUI SE DEBE PROGRAMAR LA SOLUCION
}
    
long long consulta(string A, string B)
{
    // AQUI SE DEBE PROGRAMAR LA SOLUCION
}

// ***************** EVALUADOR LOCAL *******************

#ifndef EVAL
    #include <iostream>

    using namespace std;

    void inicializar(int Q,int M);
    long long pueblo(string A, long long PA);
    long long consulta(string A, string B);

    int main()
    {
        ios::sync_with_stdio(false);
        cin.tie(nullptr);
        int localQ, localM;
        cin >> localQ >> localM;
        inicializar(localQ, localM);
        for (int i=0;i<localQ;i++)
        {
            int t;
            cin >> t;
            if (t == 1)
            {
                string A;
                cin >> A;
                long long PA;
                cin >> PA;
                cout << pueblo(A,PA) << "\n";
            }
            else if (t == 2)
            {
                string A,B;
                cin >> A >> B;
                cout << consulta(A,B) << "\n";
            }
            else
            {
                cout << "OPERACION INVALIDA!" << endl;
                return 1;
            }
        }
        return 0;
    }
#endif
