#include <string>

using namespace std;

void parte(int tam, int i);

int galletitas(string cadena, int G, int D, int T)
{
    // AQUI SE DEBE PROGRAMAR LA SOLUCION
}

// ***************** EVALUADOR LOCAL *******************

#ifndef EVAL

    #include <iostream>
    #include <vector>
    #include <string>
    #include <cassert>

    using namespace std;

    int galletitas(string cadena, int G, int D, int T);

    vector<int> _EVALUADOR__evaluadorGlobalVtam;
    vector<int> _EVALUADOR__evaluadorGlobalVi;

    void parte(int tam, int i)
    {
        _EVALUADOR__evaluadorGlobalVtam.push_back(tam);
        _EVALUADOR__evaluadorGlobalVi.push_back(i);
    }

    using namespace std;

    int main()
    {
        ios::sync_with_stdio(false);
        cin.tie(nullptr);
        string s; cin >> s;
        int G,D,T; cin >> G >> D >> T;
        cout << galletitas(s, G,D,T) << "\n";
        assert(_EVALUADOR__evaluadorGlobalVi.size() == _EVALUADOR__evaluadorGlobalVtam.size());
        cout << _EVALUADOR__evaluadorGlobalVi.size() << "\n";
        for (int i=0;i<int(_EVALUADOR__evaluadorGlobalVi.size());i++)
            cout << _EVALUADOR__evaluadorGlobalVtam[i] << " " << _EVALUADOR__evaluadorGlobalVi[i] << "\n";
        return 0;
    }
#endif
