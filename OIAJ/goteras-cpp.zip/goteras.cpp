#include <vector>

using namespace std;

long long medir(long long x);

vector<long long> goteras(int N, long long L)
{
    // AQUI SE DEBE PROGRAMAR LA SOLUCION
}


// ***************** EVALUADOR LOCAL *******************

#ifndef EVAL

    #include <iostream>
    #include <vector>
    #include <set>
    #include <cassert>
    #include <cstdlib>

    using namespace std;

    vector<long long> goteras(int N, long long L);

    set<long long> setDeLasGoteras;

    long long MAXIMO_X_PERMITIDO;

    long long medir(long long x) {
        cout << "medir(" << x << ") = ";
        if (x < 1 || x > MAXIMO_X_PERMITIDO)
        {
            cout << "MEDICION INVALIDA" << endl;
            exit(0);
        }
        long long ret;
        set<long long>::iterator sig = setDeLasGoteras.lower_bound(x);
        if (sig == setDeLasGoteras.end()) {
            assert(sig != setDeLasGoteras.begin());
            --sig;
            assert(x - *sig > 0LL);
            ret = x - *sig;
        }
        else {
            ret = *sig - x;
            assert(ret >= 0LL);
            if (sig != setDeLasGoteras.begin()) {
                --sig;
                long long otra = x - *sig;
                assert(otra > 0LL);
                if (otra < ret)
                    ret = otra;
            }
        }
        cout << ret << endl;
        return ret;
    }

    int main()
    {
        int N;
        cin >> N >> MAXIMO_X_PERMITIDO;
        for (int i=0;i<N;i++) {
            long long x; cin >> x;
            setDeLasGoteras.insert(x);
        }
        bool pri = true;
        for (long long x : goteras(N,MAXIMO_X_PERMITIDO)) {
            if (pri) pri = false;
            else cout << " ";
            cout << x;
        }
        cout << endl;
        return 0;
    }
#endif
