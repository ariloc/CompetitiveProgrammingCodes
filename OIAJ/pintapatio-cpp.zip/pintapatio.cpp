#include <vector>
#include <string>

using namespace std;

vector<string> pintapatio(vector<string> mural)
{
    // AQUI SE DEBE PROGRAMAR LA SOLUCION
}

// ***************** EVALUADOR LOCAL *******************

#ifndef EVAL

    #include <iostream>
    #include <vector>
    #include <string>

    using namespace std;

    vector<string> pintapatio(vector<string> mural);

    int main()
    {
        ios::sync_with_stdio(false);
        cin.tie(nullptr);
        
        int N,M;
        cin >> N >> M;
        vector<string> mural(N);
        for (int i=0;i<N;i++)
            cin >> mural[i];
        vector<string> pasadas = pintapatio(mural);
        cout << pasadas.size() << "\n";
        for (const string &pasada : pasadas)
            cout << pasada << "\n";
        return 0;
    }
#endif
