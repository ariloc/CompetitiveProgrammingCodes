#include <iostream>
#include <string>
#include <vector>

using namespace std;

long long distanciamiento(int W, int H, vector<int> &x, vector<int> &y);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    int W;
    cin >> W;
    int H;
    cin >> H;
    vector<int> x;
    vector<int> y;
    x.resize(n);
    y.resize(n);
    for (int i = 0; i < n; i++) {
        cin >> x[i];
        cin >> y[i];
    }
    long long returnedValue;
    returnedValue = distanciamiento(W,H,x,y);
    cout << returnedValue << "\n";
    return 0;
}
