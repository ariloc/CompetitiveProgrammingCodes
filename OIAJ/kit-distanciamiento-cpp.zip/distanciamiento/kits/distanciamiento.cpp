#include <string>
#include <vector>

using namespace std;

long long distanciamiento(int W, int H, vector<int> &x, vector<int> &y) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
